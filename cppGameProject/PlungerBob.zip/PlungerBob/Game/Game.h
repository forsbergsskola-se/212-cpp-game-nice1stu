#pragma once

class CGame
{
public:

	CGame();
	~CGame();

	bool Create();
	void Destroy();

	void Update();
	void Render();

private:

};