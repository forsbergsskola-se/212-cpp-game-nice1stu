#pragma once
class CGame
{
};

